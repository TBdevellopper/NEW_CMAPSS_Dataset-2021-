function [data_Cell]=upload_data(A,X,Y,filename)
% Preparing data
% 1) Determine unites (n_u)
uniq_unites=unique(A(1,:));
count=0;
for n_u=1:length(uniq_unites)
count=count+1;
% 3) Upload cycles
data_Cell.filename{n_u,1}=filename;
data_Cell.UnitNumber(count)=uniq_unites(n_u);
I=find(A(1,:)==uniq_unites(n_u));
data_Cell.X{n_u,1}=X(:,I);
data_Cell.Y{n_u,1}=Y(:,I);
% 4) Preprocess (Dimensionality reduction,Normalization)
% 4-1) Dimensionality reduction
numberOfDimensions = 5;
coeff = pca(data_Cell.X{n_u,1}');
reducedDimension = coeff(:,1:numberOfDimensions);
data_Cell.X{n_u,1}=(data_Cell.X{n_u,1}'*reducedDimension)';
for i=1:size(data_Cell.X{n_u},1)
% 4-2) Denoising
data_Cell.X{n_u,1}(i,:) = wdenoise(data_Cell.X{n_u,1}(i,:));
% 4-3) Normalization
data_Cell.X{n_u,1}(i,:)=scaledata(data_Cell.X{n_u,1}(i,:),0,1);% Uploading inputs,0,1);
end
% 5) Feature sellection based on correlation analysis(heatmap)
data_Cell.X{n_u,1}=data_Cell.X{n_u,1}(3,:);
end
end