function [X_new]=subsample_NCMAPSS(X,subsampling_rate)
Q=size(X,2);
[subsampling_idx] = divideint(Q,subsampling_rate,0,1-subsampling_rate);
X_new=X(:,subsampling_idx);
end