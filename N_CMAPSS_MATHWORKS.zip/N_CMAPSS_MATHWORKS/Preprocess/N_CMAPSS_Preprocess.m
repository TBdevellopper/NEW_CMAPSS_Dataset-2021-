function [data_Train,data_Test]=N_CMAPSS_Preprocess(A_dev,X_s_dev,Y_dev,A_test,X_s_test,Y_test,filename)
% Preparing development set 
[data_Train]=upload_data(A_dev,X_s_dev,Y_dev,filename);
% Preparing test set 
[data_Test]=upload_data(A_test,X_s_test,Y_test,filename);
end