function[SCORE,S,Error,RMSE]=Score(Y_hat,Y)
RUL_hat=[]; % predicted RUL
RUL=[];     % desired RUL
for i = 1:numel(Y_hat)
    EoL(i)=Y{i}(end);            % End of life "desired"
    EoL_hat(i) = Y_hat{i}(end);  % End of life "predicted"
    RUL_hat=[RUL_hat;EoL_hat(i)]; 
    RUL=[RUL; EoL(i)];
end
RUL_hat=double(RUL_hat);
RUL=double(RUL);
earlyPenalty = 13;
latePenalty = 10;
Error = RUL_hat - RUL;        % Prediction error
S = zeros(size(Error));
%%% LATE prediction, pred > trueRUL, pred - trueRUL > 0
Idx = find(Error >= 0);
FNR = length(Idx) / length(RUL); % false negative rate
S(Idx) = exp(Error(Idx)/latePenalty)-1;
%%%% EARLY
Idx = find(Error < 0);
FPR = length(Idx) / length(RUL);% false positive rate
S(Idx) = exp(-Error(Idx)/earlyPenalty)-1;% score of each prediction
SCORE=sum(S);% score sum
RMSE=sqrt(mean(Error)^2);% RMSE
end