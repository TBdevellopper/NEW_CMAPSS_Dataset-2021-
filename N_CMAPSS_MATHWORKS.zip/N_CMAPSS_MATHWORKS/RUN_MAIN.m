%%
% 
%  make sure to extract the NCMAPSS files to the folder named "NEW_CMAPSS". 
%  You also need to change the filenames to meet MATLAB requirements
%  (replace hyphens with dashes).
%  Note: We encountered some problems while uploading file "N-CMAPSS_DS08d-010.h5".
%  Therefore, we recommend removing it in case you face the same problem.
%  The datset is available at: https://phm-datasets.s3.amazonaws.com/NASA/17.+Turbofan+Engine+Degradation+Simulation+Data+Set+2.zip.
% 
clc
clear
rng('default')
addpath('Performances','ML','Preprocess','NEW_CMAPSS','Prog_Net','Uncertainty');
%
listing = dir('NEW_CMAPSS\\*.h5');
%
for i=1:numel(listing)
i
filename=listing(i).name;
% Load data
subsampling_rate=0.00005;% The subsampling rate belongs to [0,1] can be set according to your computer performance 
% The higher the sampling rate, the more data may be involved.
% 1) Development set
W_dev   = subsample_NCMAPSS(h5read(filename,'/W_dev'),subsampling_rate);          % W
X_s_dev = subsample_NCMAPSS(h5read(filename,'/X_s_dev'),subsampling_rate);        % X_s
X_v_dev = subsample_NCMAPSS(h5read(filename,'/X_v_dev'),subsampling_rate);        % X_v
T_dev   = subsample_NCMAPSS(h5read(filename,'/T_dev'),subsampling_rate);          % T
Y_dev   = subsample_NCMAPSS(h5read(filename,'/Y_dev'),subsampling_rate);          % RUL  
A_dev   = subsample_NCMAPSS(h5read(filename,'/A_dev'),subsampling_rate);          % Auxiliary
% 2) Test set
W_test   = subsample_NCMAPSS(h5read(filename,'/W_test'),subsampling_rate);          % W
X_s_test = subsample_NCMAPSS(h5read(filename,'/X_s_test'),subsampling_rate);        % X_s
X_v_test = subsample_NCMAPSS(h5read(filename,'/X_v_test'),subsampling_rate);        % X_v
T_test   = subsample_NCMAPSS(h5read(filename,'/T_test'),subsampling_rate);          % T
Y_test   = subsample_NCMAPSS(h5read(filename,'/Y_test'),subsampling_rate);          % RUL  
A_test   = subsample_NCMAPSS(h5read(filename,'/A_test'),subsampling_rate);          % Auxiliary
% 3) Variables names
W_var   = h5read(filename,'/W_var');
X_s_var = h5read(filename,'/X_s_var'); 
X_v_var = h5read(filename,'/X_v_var');
T_var   = h5read(filename,'/T_var');
A_var   = h5read(filename,'/A_var');
% 4)
if i==1
[Training,Testing]= N_CMAPSS_Preprocess(A_dev,X_s_dev,Y_dev,A_test,X_s_test,Y_test,filename);
else
[training,testing]= N_CMAPSS_Preprocess(A_dev,X_s_dev,Y_dev,A_test,X_s_test,Y_test,filename);
% Concatinate develloping set
Training.filename=[Training.filename; training.filename];
Training.UnitNumber=[Training.UnitNumber training.UnitNumber];
Training.X=[Training.X; training.X];
Training.Y=[Training.Y; training.Y];
% Concatinate testing set
Testing.filename=[Testing.filename; testing.filename];
Testing.UnitNumber=[Testing.UnitNumber testing.UnitNumber];
Testing.X=[Testing.X; testing.X];
Testing.Y=[Testing.Y; testing.Y];
end

end
clearvars -except Training Testing
%% Training of ML model without Transfer Learning
X=Training.X;% Training inputs
Y=Training.Y;% Training RUL
% Training 
[network]= LSTM_TB(X,Y);
LSTM_ML=network.LSTM;% Get trained model
info_ML=network.info;% Get information about the training mdel
Xts=Testing.X;
Yts=Testing.Y;
% Testing
Yts_hat_ML=predict(LSTM_ML,Xts');
% Performances of Prognosis model
[SCORE_ML,S_ML,Error_ML,RMSE_ML]=Score(Yts_hat_ML,Yts);
clearvars -except Training Testing X Y Xts Yts Yts_hat_ML LSTM_ML info_ML ...
          SCORE_ML S_ML Error_ML RMSE_ML 
%% Training The Trensfer learning model
load('ProgNet');% Load a Pretrained Neural Network
% Training 
[network]= LSTM_TB_Transfer(X,Y,ProgNet);% Train the LSTM model on the Target domain
LSTM_TL=network.LSTM;
info_TL=network.info;
% Testing
Yts_hat_TL=predict(LSTM_TL,Xts');
% Performances of Prognosis model
[SCORE_TL,S_TL,Error_TL,RMSE_TL]=Score(Yts_hat_TL,Yts);

clearvars -except Training Testing X Y Xts Yts...
          Yts_hat_ML LSTM_ML info_ML ...
          Yts_hat_TL LSTM_TL info_TL ...
          SCORE_ML S_ML Error_ML RMSE_ML ...
          SCORE_TL S_TL Error_TL RMSE_TL
%% PLot loss functions bahaviour
Loss_ML=info_ML.TrainingLoss;
Loss_TL=info_TL.TrainingLoss;
%
figure(1)
plot(Loss_ML,'LineWidth',2)
hold on
plot(Loss_TL)
hold off
xlabel('Iterations','LineWidth',2)
ylabel('Loss')
lgd=legend('LSTM','ProgNet');
lgd.EdgeColor="none";
lgd.Color="none";
clearvars -except Training Testing X Y Xts Yts ...
          Yts_hat_ML LSTM_ML info_ML ...
          Yts_hat_TL LSTM_TL info_TL ...
          SCORE_ML S_ML Error_ML RMSE_ML ...
          SCORE_TL S_TL Error_TL RMSE_TL
%% PLot curve fit of the Test set
figure(2)
for i=1:numel(Yts)
L=ceil(sqrt(numel(Yts)));
subplot(L,L,i);
Idx=scaledata(1:length(Yts{i}),0,1);
% CI
confidence=90;
index = [Idx, fliplr(Idx)];
[range,CI_min,CI_max]=CI_range(double(Yts{i}),double(Yts_hat_ML{i}),confidence);% determine confedance range
% Plot CI
inBetween = [CI_min, fliplr(CI_max)];
g=fill(index, inBetween, [0.3569    0.8118    0.9569]);
g.LineStyle=':';
g.LineWidth=2;
g.EdgeColor='none';
hold on; 
% plot predictions
plot(Idx,Yts{i},'-','LineWidth',1); 
plot(Idx,Yts_hat_ML{i},'.','LineWidth',1);
plot(Idx,Yts_hat_TL{i},'.','LineWidth',1);
hold off
title([Testing.filename{i,1}(10:end-3)...
       ' {' num2str(Testing.UnitNumber(i)) '}'],...
       'Interpreter','non','FontWeight','Normal');
   if i==1
xlabel('Relative time');
ylabel('RUL');
lgd=legend('CI','RUL','LSTM','ProgNet');
lgd.EdgeColor="none";
lgd.Color="none";
   end
   
end
clearvars -except Testing X Y Xts Yts Yts_hat_ML LSTM_ML info_ML Yts_hat_TL LSTM_TL info_TL ...
          SCORE_ML S_ML Error_ML RMSE_ML ...
          SCORE_TL S_TL Error_TL RMSE_TL
%% Performances of Prognosis model
figure (3)
% Score function
subplot(1,2,1)
plot(Error_ML,S_ML,'o','LineWidth',2);
hold on
%
plot(Error_TL,S_TL,'o','LineWidth',2);
hold off
xlabel({'Error','(a)'});
ylabel('Score');
lgd=legend('LSTM','ProgNet');
lgd.EdgeColor="none";
lgd.Color="none";
% RMSE
subplot(1,2,2)
plot(Error_ML,abs(Error_ML),'o','LineWidth',2);
hold on
plot(Error_TL,abs(Error_TL),'o','LineWidth',2);
hold off
xlabel({'Error','(b)'});
ylabel('RMSE');
lgd=legend('LSTM','ProgNet');
lgd.EdgeColor="none";
lgd.Color="none";













 