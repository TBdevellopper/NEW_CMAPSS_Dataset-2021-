function [range,CI_min,CI_max]=CI_range(y,y_hat,confidence)
% confidence= 99%, 95%, 90 %
interval=CI_interval(y,confidence,2);
CI_min=(y-interval);% confidance interval lower bound
CI_max=(y+interval);% confidance interval upper bound
I1=find(y_hat>CI_max);
I2=find(y_hat<CI_min);
range=(length(I1)+length(I2))/length(y_hat);
end