function [x]=addnoise(x,percentage)
% Make the spread of the Gaussians be percentage% of the x values
sigmas = percentage* x; % Also a column vector.
% Create the noise values that we'll add to a.
randomNoise = randn(length(x), 1) .* sigmas;
% Add noise to a to make an output column vector.
x = (x + randomNoise);
end